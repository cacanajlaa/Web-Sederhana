<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <title>Portofolio</title>
</head>
<body>
    <header>
        <h1>Allara <a href="index.php"></a></h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="project.php">Projects</a></li>
                <li class="active"><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <section id="contact">
        <div class="container">
            <h2>Contact</h2>
            <p>Email: <i class="fas fa-envelope"></i> aaa@gmail.com </p>
            <p>Linkedin : <i class="fab fa-linkedin"></i><a href="#">Linkedin.com/in/aaa</a></p>

            <h2>Contact Us</h2>
            <form id="formcontact">
                <label for="name">Nama</label>
                <input type="text" id="name" name="name" required>

                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>

                <label for="message">Message</label>
                <textarea name="message" id="message" required></textarea>

                <button type="submit" value="simpan">Send</button>
            </form>
        </div>
    </section>

    <footer>
        <p>&copy; Tes | All Right Reserved</p>
    </footer>
</body>
</html>

<?php
    include "config.php";
if (isset($_POST['simpan'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    $koneksi->query("insert into contact(nama, email, pesan) values ('$name', '$email', '$message')") or die(mysqli_error($koneksi));
    header("location:contact.php");
    //echo "<script>alert('Thank you');</script>";
    //echo "<script>location='contact.php';</script>";
}

?>