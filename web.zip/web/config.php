<?php 
/**koneksi ke database **/
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tes";

$koneksi = mysqli_connect($servername, $username, $password, $dbname);
if(!$koneksi)
{
    die("Connection Failed : ".mysqli_connect_error());
} 
?>