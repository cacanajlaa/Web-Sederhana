<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <title>Portofolio</title>
</head>
<body>
    <header>
        <h1>Allara <a href="index.php"></a></h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li class="active"><a href="about.php">About</a></li>
                <li><a href="project.php">Projects</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <section id="about">
        <div class="container">
        <h2>About Me</h2>
        <div class="tentang">
            <div class="tulisan">
            <h3>Lorem Ipsum</h3>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repudiandae dicta molestias cumque enim consequatur tempore quos quas alias illo fugiat unde suscipit fugit neque accusamus, excepturi officia optio voluptas reprehenderit!</p>
        </div>
        <img src="img/tes1.jpg" alt="" class="imgabout">
    </div>
        </div>
    </section>
    
    <footer>
        <p>&copy; Tes | All Right Reserved</p>
    </footer>
</body>
</html>