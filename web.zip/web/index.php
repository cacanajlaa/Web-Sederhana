<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <title>Portofolio</title>
</head>
<body>
    <header>
        <h1>Allara <a href="index.php"></a></h1>
        <nav>
            <ul>
                <li class="active"><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="project.php">Projects</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <section id="about">
        <div class="container">
        <h2>About Me</h2>
        <div class="tentang">
            <div class="tulisan">
            <h3>Lorem Ipsum</h3>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repudiandae dicta molestias cumque enim consequatur tempore quos quas alias illo fugiat unde suscipit fugit neque accusamus, excepturi officia optio voluptas reprehenderit!</p>
        </div>
        <img src="img/tes1.jpg" alt="" class="imgabout">
    </div>
        </div>
    </section>
    
    <section id="project">
        <div class="container">
            <h2>Projects</h2>
            <div class="foto">
                <div class="fotoproyek">
                    <h3>Project 1</h3>
                    <img src="img/tes.jpg" alt="" class="imgproject">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore incidunt qui sapiente provident amet expedita eum et modi aliquid dignissimos, commodi exercitat</p>
                </div>
                <div class="fotoproyek">
                    <h3>Project 2</h3>
                    <img src="img/tes1.jpg" alt="" class="imgproject">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore incidunt qui sapiente provident amet expedita eum et modi aliquid dignissimos, commodi exercitat</p>
                </div>
                <div class="fotoproyek">
                    <h3>Project 3</h3>
                    <img src="img/tes.jpg" alt="" class="imgproject">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore incidunt qui sapiente provident amet expedita eum et modi aliquid dignissimos, commodi exercitat</p>
                </div>
            </div>
        </div>
    </section>

    <section id="contact">
        <div class="container">
            <h2>Contact</h2>
            <p>Email: <i class="fas fa-envelope"></i> aaa@gmail.com </p>
            <p>Linkedin : <i class="fab fa-linkedin"></i><a href="#">Linkedin.com/in/aaa</a></p>

            <h2>Contact Us</h2>
            <form method="post">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" required>

                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>

                <label for="message">Message</label>
                <textarea name="message" id="message" required></textarea>

                <button type="submit">Send</button>
            </form>
        </div>
    </section>
    <footer>
        <p>&copy; Tes | All Right Reserved</p>
    </footer>
</body>
</html>