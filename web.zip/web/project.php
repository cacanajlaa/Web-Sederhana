<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <title>Portofolio</title>
</head>
<body>
    <header>
        <h1>Allara <a href="index.php"></a></h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li class="active"><a href="project.php">Projects</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>
    
    <section id="project">
        <div class="container">
            <h2>Projects</h2>
            <div class="foto">
                <div class="fotoproyek">
                    <h3>Project 1</h3>
                    <img src="img/tes.jpg" alt="" class="imgproject">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore incidunt qui sapiente provident amet expedita eum et modi aliquid dignissimos, commodi exercitat</p>
                </div>
                <div class="fotoproyek">
                    <h3>Project 2</h3>
                    <img src="img/tes1.jpg" alt="" class="imgproject">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore incidunt qui sapiente provident amet expedita eum et modi aliquid dignissimos, commodi exercitat</p>
                </div>
                <div class="fotoproyek">
                    <h3>Project 3</h3>
                    <img src="img/tes.jpg" alt="" class="imgproject">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore incidunt qui sapiente provident amet expedita eum et modi aliquid dignissimos, commodi exercitat</p>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <p>&copy; Tes | All Right Reserved</p>
    </footer>
</body>
</html>